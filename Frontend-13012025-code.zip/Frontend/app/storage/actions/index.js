import * as authActions from "./auth";
import * as docActions from "./document";

export {authActions, docActions};