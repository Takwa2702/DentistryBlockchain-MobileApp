import * as authReducer from "./auth";
import * as docReducer from "./document";

export {authReducer, docReducer};