import { StyleSheet} from "react-native";

const sharedstyles = StyleSheet.create({
    //header 
    header: {
        flex: 1, 
        backgroundColor: '#fff',
        paddingHorizontal: 20,
        paddingVertical: 30,
        alignItems: 'center'
    },
    footer: {

    }
}); 

export {sharedstyles};