const i18n = {
    newDoc: {
        title: "New Patient Document",
        subTitle: "Add "
    }
}

export {i18n};