import DocumentScreen from "./screens/DocumentScreen";
import IssuesScreen from "./screens/IssuesScreen";
import MedicinesScreen from "./screens/MedicinesScreen";
import PatientsScreen from "./screens/PatientsScreen";

export {DocumentScreen, IssuesScreen, MedicinesScreen, PatientsScreen};