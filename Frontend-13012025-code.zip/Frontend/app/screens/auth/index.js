import SignInScreen from "./screens/signInScreen";
import OnBoardingScreen from "./screens/onBoardingScreen";

export {SignInScreen,OnBoardingScreen};