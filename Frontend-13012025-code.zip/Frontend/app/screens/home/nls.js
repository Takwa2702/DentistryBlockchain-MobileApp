const i18n = {
    //home screen
    home: {
        welcomeTitle: "Hello , ",
        welcomeSubTitle: "Stay updated with recent information about your medical records and monitor your data accessibility",

    }
}

export {i18n};